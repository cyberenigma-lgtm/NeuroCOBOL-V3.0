#ifndef NC_PARSER_H
#define NC_PARSER_H

#include "nc_lexer.h"

typedef enum {
    NODE_PROGRAM,
    NODE_DATA,
    NODE_LOGIC,
    NODE_DEFINE,
    NODE_IDENTIFIER,
    NODE_STRING_LITERAL,
    NODE_SHOW,
    NODE_IF,
    NODE_BLOCK,
    NODE_ELSE,
    NODE_WINDOW,
    NODE_BUTTON,
    NODE_FIELD,
    NODE_OPEN,
    NODE_READ,
    NODE_WRITE,
    NODE_CLOSE,
    NODE_MODULE_DECL, // Registro de Módulo de IA (V2.6)
    NODE_BUS_SEND,    // Envío al NeuroBUS
    NODE_BUS_RECV,    // Recepción del NeuroBUS
    NODE_NITRO,       // Activación de Overdrive/Nitro
    
    // V2.7 - Industrial y Defensa
    NODE_IMPORT,      // Importación de Bibliotecas
    NODE_COMPRESSED_DATA, // Datos BCD/Punto Fijo
    
    NODE_ERROR
} ASTNodeType;

typedef struct ASTNode {
    ASTNodeType type;
    char text[64];
    struct ASTNode* left;
    struct ASTNode* right;
    struct ASTNode* next;
} ASTNode;

#ifdef __cplusplus
extern "C" {
#endif

ASTNode* nc_parse(const char* source);
void nc_free_ast(ASTNode* node);

#ifdef __cplusplus
}
#endif

#endif
